setTimeout("window.open('http://apoio.deve/Intranet/', '_self');", 300000);
